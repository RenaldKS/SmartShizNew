package nodomain.freeyourgadget.gadgetbridge.devices;


public enum SleepAsAndroidFeature {
    HEART_RATE,
    ALARMS,
    NOTIFICATIONS,
    ACCELEROMETER,
    OXIMETRY,
    SPO2
}
